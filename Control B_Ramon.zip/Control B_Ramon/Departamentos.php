<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc"?>
</head>
<body>
    <?php
    //var_dump(f_todosDepartamentos());
    ?>
    <form action="EmpleadosDepartamento.php" method="post">
        <select name="codDepartamento" id="">
            <option value="-1">--Departamentos--</option>
            <?php
            $nombresDepartamentos = f_todosDepartamentos();
            foreach($nombresDepartamentos as $codDepartamento => $datosDepartamento){
                ?>
                <option value="<?php echo $codDepartamento;?>">
                    <?php echo $datosDepartamento["Nombre"];?>
                </option>
                <?php
            }
            ?>
        </select>
        <input type="submit" value="Mostrar empleados">
    </form>
</body>
</html>