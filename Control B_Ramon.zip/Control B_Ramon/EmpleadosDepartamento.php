<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc"?>
</head>
<body>
    <?php
    if(isset($_POST["codDepartamento"])){
        $codDepartamento = $_POST["codDepartamento"];
        //var_dump($codDepartamento);
        if($codDepartamento == -1){
            echo "No has seleccionado ningún departamento";
        }else{
            $nombreEmpleado= f_empleadosDepartamento($codDepartamento);
            $Sucursales = f_todosSucursales();
            //$informacionEmpleado = [$nombreEmpleado, $Sucursales];
           
            ?>
            <table>
                <tr>
                    <th>Nombre empleado</th>
                    <th>Puesto</th>
                    <th>Fecha contratación</th>
                    <th>Nombre sucursal</th>
                    <th>Direccion sucursal</th>
                    <th>Ciudad sucursal</th>
                </tr>
                <?php
                foreach($nombreEmpleado as $codEmpleado => $datosEmpleado){?>
                    <tr>
                        <td>
                             <?php echo $datosEmpleado["Empleado"];?>
                        </td>
                        <td>
                            <?php echo $datosEmpleado["Puesto"];?>
                        </td>
                        <td>
                            <?php echo $datosEmpleado["FechaContratacion"]?>
                        </td>
                        <?php foreach($Sucursales as $codSucursal => $datosSucursal){?>
                            <td>
                            <?php echo $datosSucursal["Nombre"];?>
                        </td>
                        <td>
                            <?php echo $datosSucursal["Direccion"];?>
                        </td>
                        <td>
                            <?php echo $datosSucursal["Ciudad"];?>
                        </td>

                        <?php
                        }
                        ?>
                    </tr>
                <?php    
                }
                ?>
            </table>
        <?php
        }
        ?>
    <?php
    }
    ?>
</body>
</html>